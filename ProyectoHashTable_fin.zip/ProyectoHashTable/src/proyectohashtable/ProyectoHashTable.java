/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyectohashtable;

/**
 *
 * @author elva
 */
public class ProyectoHashTable {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        InterfazProye2 ventana = new InterfazProye2();
        ventana.setVisible(true);
    }
    
}
